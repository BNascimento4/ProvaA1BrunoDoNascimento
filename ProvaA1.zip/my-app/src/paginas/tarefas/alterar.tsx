import React, { useState, useEffect } from 'react';
function AlterarTarefa() {
    const id = '1';  
    const [titulo, setTitulo] = useState('');
    const [descricao, setDescricao] = useState('');
    const [status, setStatus] = useState('Não Concluída');
    useEffect(() => {
        fetch(`http://localhost:5000/api/tarefas/buscar/${id}`)
            .then((response) => response.json())
            .then((data) => {
                setTitulo(data.titulo);
                setDescricao(data.descricao);
                setStatus(data.status);
            });
    }, [id]);
    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        fetch(`http://localhost:5000/api/tarefas/alterar/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ titulo, descricao, status }),
        })
            .then((response) => response.json())
            .then(() => {
                alert('Tarefa alterada com sucesso!');
            })
            .catch((error) => {
                console.error('Erro ao alterar tarefa:', error);
                alert('Erro ao alterar tarefa.');
            });
    };
    return (
        <div>
            <h2>Alterar Tarefa</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Título:</label>
                    <input
                        type="text"
                        value={titulo}
                        onChange={(e) => setTitulo(e.target.value)}
                    />
                </div>
                <div>
                    <label>Descrição:</label>
                    <input
                        type="text"
                        value={descricao}
                        onChange={(e) => setDescricao(e.target.value)}
                    />
                </div>
                <div>
                    <label>Status:</label>
                    <select value={status} onChange={(e) => setStatus(e.target.value)}>
                        <option value="Não Concluída">Não Concluída</option>
                        <option value="Concluída">Concluída</option>
                    </select>
                </div>
                <button type="submit">Alterar</button>
            </form>
        </div>
    );
};
export default AlterarTarefa;