import React, { useEffect, useState } from 'react';

interface Tarefa {
    id: string;
    titulo: string;
    descricao: string;
    status: string;
}

function ListarTarefas() {
    const [tarefas, setTarefas] = useState<Tarefa[]>([]);

    useEffect(() => {
        fetch('http://localhost:5000/api/tarefas/listar')
            .then((response) => response.json())
            .then((data) => setTarefas(data))
            .catch((error) => console.error('Erro ao listar tarefas:', error));
    }, []);

    return (
        <div>
            <h2>Listar Tarefas</h2>
            <ul>
                {tarefas.map((tarefa) => (
                    <li key={tarefa.id}>
                        <h3>{tarefa.titulo}</h3>
                        <p>{tarefa.descricao}</p>
                        <p>Status: {tarefa.status}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ListarTarefas;

