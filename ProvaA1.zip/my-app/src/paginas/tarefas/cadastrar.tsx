import React, { useState } from 'react';

function CadastrarTarefa() {
    const [titulo, setTitulo] = useState('');
    const [descricao, setDescricao] = useState('');
    const [categoriaId, setCategoriaId] = useState('');
    const [status, setStatus] = useState('Não Concluída');
    const [error, setError] = useState<string>('');

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();

        const novaTarefa = {
            titulo,
            descricao,
            categoriaId,
            status,
        };

        fetch('http://localhost:5000/api/tarefas/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(novaTarefa),
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Erro ao cadastrar tarefa');
                }
                return response.json();
            })
            .then(() => {
                alert('Tarefa cadastrada com sucesso');
            })
            .catch((error) => setError(error.message));
    };

    return (
        <div>
            <h2>Cadastrar Tarefa</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Título:</label>
                    <input
                        type="text"
                        value={titulo}
                        onChange={(e) => setTitulo(e.target.value)}
                    />
                </div>
                <div>
                    <label>Descrição:</label>
                    <input
                        type="text"
                        value={descricao}
                        onChange={(e) => setDescricao(e.target.value)}
                    />
                </div>
                <div>
                    <label>Categoria ID:</label>
                    <input
                        type="text"
                        value={categoriaId}
                        onChange={(e) => setCategoriaId(e.target.value)}
                    />
                </div>
                <div>
                    <label>Status:</label>
                    <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                    >
                        <option value="Não Concluída">Não Concluída</option>
                        <option value="Concluída">Concluída</option>
                        <option value="Em Andamento">Em Andamento</option>
                    </select>
                </div>
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    );
};

export default CadastrarTarefa;
