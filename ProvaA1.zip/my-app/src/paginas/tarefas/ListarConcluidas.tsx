import React, { useState, useEffect } from 'react';

interface Tarefa {
    id: string;
    titulo: string;
    descricao: string;
    status: string;
}

function ListarConcluidas() {
    const [tarefas, setTarefas] = useState<Tarefa[]>([]);

    useEffect(() => {
        fetch('http://localhost:5000/api/tarefas/concluidas')
            .then((response) => response.json())
            .then((data) => setTarefas(data))
            .catch((error) => console.error('Erro ao carregar tarefas concluídas:', error));
    }, []);

    return (
        <div>
            <h2>Tarefas Concluídas</h2>
            {tarefas.length === 0 ? (
                <p>Nenhuma tarefa concluída encontrada.</p>
            ) : (
                <ul>
                    {tarefas.map((tarefa) => (
                        <li key={tarefa.id}>
                            <h3>{tarefa.titulo}</h3>
                            <p>{tarefa.descricao}</p>
                            <p>Status: {tarefa.status}</p>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default ListarConcluidas;
