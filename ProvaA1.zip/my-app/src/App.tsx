import React, { useState } from 'react';
import ListarConcluidas from './paginas/tarefas/ListarConcluidas';
import ListarNaoConcluidas from './paginas/tarefas/ListarNaoConcluidas';
import CadastrarTarefa from './paginas/tarefas/cadastrar';
import AlterarTarefa from './paginas/tarefas/alterar';
import Listar from './paginas/tarefas/listar';
function App() {
  const [paginaAtual, setPaginaAtual] = useState<string>('listar');
  const renderPagina = () => {
    switch (paginaAtual) {
      case 'listarConcluidas':
        return <ListarConcluidas />;
      case 'listarNaoConcluidas':
        return <ListarNaoConcluidas />;
      case 'cadastrar':
        return <CadastrarTarefa />;
      case 'alterar':
        return <AlterarTarefa />;
      case 'listar':
        return <Listar />;
      default:
        return <ListarConcluidas />;
    }
  };
  return (
    <div>
      <h1>Aplicação de Tarefas</h1>
      <nav>
        <button onClick={() => setPaginaAtual('listarConcluidas')}>Listar Concluídas</button>
        <button onClick={() => setPaginaAtual('listarNaoConcluidas')}>Listar Não Concluídas</button>
        <button onClick={() => setPaginaAtual('cadastrar')}>Cadastrar Tarefa</button>
        <button onClick={() => setPaginaAtual('alterar')}>Alterar Tarefa</button>
        <button onClick={() => setPaginaAtual('listar')}>Listar Tarefa</button>
      </nav>
      <div>
        {renderPagina()}
      </div>
    </div>
  );
}
export default App;

