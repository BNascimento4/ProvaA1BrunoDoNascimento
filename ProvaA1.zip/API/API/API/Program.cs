using API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDataContext>();
builder.Services.AddCors(options => { options.AddPolicy("AcessarApi", builder => builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()); });
var app = builder.Build();


app.MapGet("/", () => "Prova A1");

//ENDPOINTS DE CATEGORIA
//GET: http://localhost:5273/api/categoria/listar
app.MapGet("/api/categoria/listar", ([FromServices] AppDataContext ctx) =>
{
    if (ctx.Categorias.Any())
    {
        return Results.Ok(ctx.Categorias.ToList());
    }
    return Results.NotFound("Nenhuma categoria encontrada");
});

//POST: http://localhost:5273/api/categoria/cadastrar
app.MapPost("/api/categoria/cadastrar", ([FromServices] AppDataContext ctx, [FromBody] Categoria categoria) =>
{
    ctx.Categorias.Add(categoria);
    ctx.SaveChanges();
    return Results.Created("", categoria);
});

//ENDPOINTS DE TAREFA
//GET: http://localhost:5273/api/tarefas/listar
app.MapGet("/api/tarefas/listar", ([FromServices] AppDataContext ctx) =>
{
    if (ctx.Tarefas.Any())
    {
        return Results.Ok(ctx.Tarefas.Include(x => x.Categoria).ToList());
    }
    return Results.NotFound("Nenhuma tarefa encontrada");
});
//POST: http://localhost:5273/api/tarefas/cadastrar
app.MapPost("/api/tarefas/cadastrar", ([FromServices] AppDataContext ctx, [FromBody] Tarefa tarefa) =>
{
    Categoria? categoria = ctx.Categorias.Find(tarefa.CategoriaId);
    if (categoria == null)
    {
        return Results.NotFound("Categoria não encontrada");
    }
    tarefa.Categoria = categoria;
    ctx.Tarefas.Add(tarefa);
    ctx.SaveChanges();
    return Results.Created("", tarefa);
});
//PUT: http://localhost:5273/tarefas/alterar/{id}
app.MapPut("/api/tarefas/alterar/{id}", async ([FromServices] AppDataContext ctx, [FromRoute] string id, [FromBody] Tarefa novaTarefa) =>
{
    if (await ctx.Categorias.AnyAsync(categoria => categoria.CategoriaId == novaTarefa.CategoriaId) == false)
    {
        return Results.NotFound("Categoria não existe");
    }
    var tarefaNova = await ctx.Tarefas.FindAsync(id);
    if (tarefaNova == null)
    {
        return Results.NotFound("Tarefa não existe");
    }
    tarefaNova.Titulo = novaTarefa.Titulo;
    tarefaNova.Descricao = novaTarefa.Descricao;
    tarefaNova.Status = novaTarefa.Status;
    tarefaNova.CategoriaId = novaTarefa.CategoriaId;
    tarefaNova.Categoria = novaTarefa.Categoria;
    await ctx.SaveChangesAsync();
    return Results.Ok("Tarefa foi alterada");
});
//GET: http://localhost:5273/tarefas/naoconcluidas
app.MapGet("/api/tarefas/naoconcluidas", async ([FromServices] AppDataContext ctx) =>
{
    var tarefasAFazer = await ctx.Tarefas.Where(tarefa => tarefa.Status != "Concluída").ToListAsync();
    if (tarefasAFazer.Count == 0)
    {
        return Results.NotFound("Não existem tarefas não concluidas!");
    }
    return Results.Ok(ctx.Tarefas.Where(tarefa => tarefa.Status != "Concluída").Include(x => x.Categoria).ToList());
});
//GET: http://localhost:5273/tarefas/concluidas
app.MapGet("/api/tarefas/concluidas", async ([FromServices] AppDataContext ctx) =>
{
    var tarefasFeita = await ctx.Tarefas.Where(tarefa => tarefa.Status == "Concluída").ToListAsync();
    if (tarefasFeita.Count == 0)
    {
        return Results.NotFound("Não existem tarefas concluidas!");
    }
    return Results.Ok(ctx.Tarefas.Where(tarefa => tarefa.Status == "Concluída").Include(x => x.Categoria).ToList());
});
app.UseCors("AcessarApi");
app.Run();
